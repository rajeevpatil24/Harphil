import os
import requests
import sys

from API_Scripts.Authentication_Token import request_parser
from Get_Audit_log import request_audit_log


class Filedoesnotexists:
    pass


try:
    AT = request_parser(request='POST',
                        filename="/Users/rapati/PycharmProjects/harphil/Authentication/API_Requests/Authentication_token_password.json",
                        api_url='https://api.discovery-staging.verifiable.com/auth/token/password')
    Filename, Token = AT.Authentication_endpoint()
    GL = request_audit_log(Token, Filename, url="https://api.discovery-staging.verifiable.com/audit/log",request="GET")
    result = GL.get_audit_log()
except Filedoesnotexists:
    print ("file doesnot exists")
