import requests
import json
import datetime
import logging
from datetime import datetime
import os

headers = {
    'Content-Type': 'application/json',
}

now = datetime.now()
os.system("rm -rf /Users/rapati/PycharmProjects/harphil/API_Scripts/*response*.json")


class request_parser():
    def __init__(self, filename, api_url, request):
        self.filename = filename
        self.api_url = api_url
        self.request_type = request

    def Authentication_endpoint(self):
        if self.request_type == "POST":
            try:
                dt_string = now.strftime("%d_%m_%Y_%H_%M_%S")
                with open(self.filename, 'r') as fo:
                    data = json.load(fo)
                    for value in data.values():
                        for api_data in value:
                            api_data = json.dumps(api_data)
                            response = requests.post(url=self.api_url, headers=headers, data=api_data)
                            with open('Auth_Token_response_' + str(dt_string) + '.json', "a") as f:
                                f.write(response.text + '\n')
                print ("Successfully created {} file".format('Auth_Token_response_' + str(dt_string) + '.json'))
                with open('Auth_Token_response_' + str(dt_string) + '.json', 'r') as fo:
                    data = json.load(fo)
                return 'Auth_Token_response_' + str(dt_string) + '.json', data['token']
            except requests.HTTPError:
                return "Failed due to HTTP Connection issue "
            except OSError:
                return "failed due to TLS CA Certificate bundle"
        elif self.request_type == "GET":
            return "GET Method not allowed to this API Request"
        elif self.request_type == "PUT":
            return "PUT Method not allowed to this API Request"
        else:
            return "Try with correct data"

# print (os.path.realpath(os.path.dirname(__file__)))
# result=request_parser(filename,api_url,cert_path)


# print (Filename)
