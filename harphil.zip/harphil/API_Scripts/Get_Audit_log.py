import requests

import json
import datetime
import logging
from datetime import datetime
import os

headers = {
    'Content-Type': 'application/json',
}

now = datetime.now()
os.system("rm -rf /Users/rapati/PycharmProjects/harphil/API_Scripts/*response*.json")


class request_audit_log():
    def __init__(self, token, filename, url, request):
        self.token = token
        self.api_url = url
        self.filename = filename
        self.request_type = request

    def get_audit_log(self):
        if self.request_type == "GET":
            try:
                dt_string = now.strftime("%d_%m_%Y_%H_%M_%S")
                response = requests.get(url=self.api_url, headers={'Content-Type': 'application/json',
                                                                   'Authorization': 'Bearer {}'.format(self.token)})
                with open('get_audit_log_response_' + str(dt_string) + '.json', "a") as f:
                    f.write(response.text + '\n')
                return "Successfully created {} file".format('get_audit_log_response_' + str(dt_string) + '.json')
            except requests.HTTPError:
                return "Failed due to HTTP Connection issue "
            except OSError:
                return "failed due to TLS CA Certificate bundle"
        elif self.request_type == "GET":
            return "GET Method not allowed to this API Request"
        elif self.request_type == "PUT":
            return "PUT Method not allowed to this API Request"
        else:
            return "Try with correct data"
